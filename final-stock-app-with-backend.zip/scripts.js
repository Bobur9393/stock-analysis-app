// 📊 Кнопка анализа акций
const analyzeButton = document.getElementById('analyzeBtn');

// ... (содержимое обрезано для примера) ...
